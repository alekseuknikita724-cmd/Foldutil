package dev.fold.util;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class FoldUtil implements ClientModInitializer {
    static KeyBinding menuKey;
    static boolean openMenu;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.foldutil.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F3, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) openMenu = true;
            if (openMenu && mc.player != null) { openMenu = false; mc.setScreen(new MenuScreen()); }
            if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
            tick(mc);
        });

        // Для телефона: открыть меню командой /foldutil в чате
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("foldutil").executes(ctx -> { openMenu = true; return 1; })));

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of("foldutil", "hud"), (ctx, tickCounter) -> Hud.render(ctx));
    }

    static void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;

        // --- Aim Assist: плавно доводит прицел до ближайшей цели в FOV ---
        LivingEntity best = null;
        double bestDiff = Settings.aimFov;
        Vec3d eye = p.getEyePos();
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(Settings.aimRange), x -> x != p && x.isAlive() && !(x instanceof ArmorStandEntity))) {
            Vec3d c = e.getBoundingBox().getCenter();
            double dx = c.x - eye.x, dz = c.z - eye.z;
            float yawTo = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90);
            double diff = Math.abs(MathHelper.wrapDegrees(yawTo - p.getYaw()));
            if (diff < bestDiff) { bestDiff = diff; best = e; }
        }
        Settings.target = best;

        if (Settings.aimAssist && best != null) {
            Vec3d c = best.getBoundingBox().getCenter();
            double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
            float yawTo = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90);
            float pitchTo = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            float s = Settings.aimSpeed;
            p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(yawTo - p.getYaw()), -s, s));
            p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchTo - p.getPitch(), -s, s), -90, 90));
        }

        // --- Trigger Bot: бьёт, когда прицел на мобе и кулдаун заряжен ---
        if (Settings.triggerBot && mc.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity le && le.isAlive() && !(le instanceof ArmorStandEntity)
                && p.getAttackCooldownProgress(0.5f) >= 0.95f) {
            mc.interactionManager.attackEntity(p, le);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}

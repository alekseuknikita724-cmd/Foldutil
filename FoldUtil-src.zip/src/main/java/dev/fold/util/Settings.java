package dev.fold.util;

import net.minecraft.entity.LivingEntity;

public class Settings {
    public static boolean targetInfo = true, aimAssist = false, triggerBot = false, visuals = true;
    public static float aimSpeed = 6f, aimRange = 5f, aimFov = 60f;
    public static LivingEntity target; // текущая цель для HUD
}

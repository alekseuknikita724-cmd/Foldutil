package dev.fold.util;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MenuScreen extends Screen {
    public MenuScreen() { super(Text.literal("FoldUtil")); }

    @Override
    protected void init() {
        int x = width / 2 - 80, y = height / 2 - 55;
        add("Target Info", () -> Settings.targetInfo = !Settings.targetInfo, () -> Settings.targetInfo, x, y);
        add("Aim Assist", () -> Settings.aimAssist = !Settings.aimAssist, () -> Settings.aimAssist, x, y + 26);
        add("Trigger Bot", () -> Settings.triggerBot = !Settings.triggerBot, () -> Settings.triggerBot, x, y + 52);
        add("Visuals", () -> Settings.visuals = !Settings.visuals, () -> Settings.visuals, x, y + 78);
    }

    private void add(String name, Runnable toggle, java.util.function.BooleanSupplier state, int x, int y) {
        addDrawableChild(ButtonWidget.builder(label(name, state.getAsBoolean()), b -> {
            toggle.run();
            b.setMessage(label(name, state.getAsBoolean()));
        }).dimensions(x, y, 160, 20).build());
    }

    private Text label(String n, boolean on) { return Text.literal(n + ": " + (on ? "§aВКЛ" : "§cВЫКЛ")); }

    @Override
    public void render(DrawContext g, int mx, int my, float d) {
        g.fillGradient(0, 0, width, height, 0xB0000010, 0xB0200040);
        g.drawCenteredTextWithShadow(textRenderer, "FoldUtil", width / 2, height / 2 - 75, Hud.rainbow(0));
        super.render(g, mx, my, d);
    }
}

package dev.fold.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public class Hud {
    /** Анимированный радужный цвет для акцентов */
    static int rainbow(float offset) {
        float h = ((System.currentTimeMillis() % 4000) / 4000f + offset) % 1f;
        return 0xFF000000 | MathHelper.hsvToRgb(h, 0.7f, 1f);
    }

    static void render(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        // Watermark + список модулей
        if (Settings.visuals) {
            int w = mc.getWindow().getScaledWidth();
            g.fillGradient(0, 0, w, 2, rainbow(0), rainbow(0.5f));
            String[] names = {
                Settings.aimAssist ? "AimAssist" : null,
                Settings.triggerBot ? "TriggerBot" : null,
                Settings.targetInfo ? "TargetInfo" : null };
            int y = 6, i = 0;
            g.drawTextWithShadow(mc.textRenderer, "FoldUtil", 6, 6, rainbow(0));
            for (String n : names) {
                if (n == null) continue;
                int tw = mc.textRenderer.getWidth(n);
                g.fill(w - tw - 10, y - 2, w - 2, y + 10, 0x90000000);
                g.fill(w - 2, y - 2, w, y + 10, rainbow(i++ * 0.12f));
                g.drawTextWithShadow(mc.textRenderer, n, w - tw - 6, y, 0xFFFFFFFF);
                y += 12;
            }
        }

        // Target Info
        LivingEntity t = Settings.target;
        if (Settings.targetInfo && t != null) {
            int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
            int x = w / 2 + 30, y = h / 2 + 20, bw = 110;
            g.fillGradient(x, y, x + bw, y + 38, 0xC0101018, 0xC0202035);
            g.fill(x, y, x + 2, y + 38, rainbow(0));
            g.drawTextWithShadow(mc.textRenderer, t.getName().getString(), x + 6, y + 4, 0xFFFFFFFF);
            float hp = MathHelper.clamp(t.getHealth() / t.getMaxHealth(), 0f, 1f);
            g.fill(x + 6, y + 16, x + bw - 6, y + 22, 0xFF303030);
            int col = hp > 0.5f ? 0xFF55FF55 : hp > 0.25f ? 0xFFFFAA00 : 0xFFFF5555;
            g.fill(x + 6, y + 16, x + 6 + (int) ((bw - 12) * hp), y + 22, col);
            String info = String.format("%.1f HP  |  %.1f м", t.getHealth(), mc.player.distanceTo(t));
            g.drawTextWithShadow(mc.textRenderer, info, x + 6, y + 26, 0xFFAAAAAA);
        }
    }
}
